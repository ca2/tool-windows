Sticky Notes
Copyright (c) 2010 Igor Vigdorchik
Web site: http://www.igorv.com

Description
===========
The Sticky Notes application allows you to create electronic sticky notes
directly on your Windows desktop. The Sticky Notes are just like paper
post-it notes for your computer. Jot down tasks, messages, ideas, appointments,
phone numbers, birthdays in a note and stick it on the desktop.

System Requirements
===================
Sticky Notes works on Windows 2000, Windows XP, Windows Server 2003, Windows Vista and Windows 7.

How to install
==============
Sticky Notes doesn't require any installation process or additional DLLs and it does not 
use the registry. Just unzip files that you've just downloaded to any folder of your choice 
and click StickyNotes.exe.
If you install over the previous version back up your notes (through the Options dialog) before
as a precaution.

How to uninstall
================
To uninstall Sticky Notes simply delete the StickyNotes.exe, StickyNotes.ini, StickyNotes.chm and the data file.

License
=======
Sticky Notes is a free software. Free use is limited to the Sticky Notes
in whole. Usage of parts only, for example the database or the plug-ins,
is not permitted.
You may not alter, merge, modify, adapt, decompile or disassemble
Sticky Notes or create derivative works based upon this software.
You may not sell, rent, lease, or sublicense the Sticky Notes.
You are allowed to freely distribute this utility via floppy disk, CD-ROM,
Internet, or in any other way, as long as you don't charge anything for this.

Disclaimer
==========
The software is provided "AS IS" without any warranty, either expressed
or implied, including, but not limited to, the implied warranties of
merchantability and fitness for a particular purpose. The author will not
be held liable for any special, incidental, consequential or indirect damages
arising from the use of this software.